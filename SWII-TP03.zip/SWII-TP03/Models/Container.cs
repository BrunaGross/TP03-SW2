﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SWII_TP03.Models {
    public class Container {
        public int id {get;set;}
        public int numero { get; set; }
        public String tipo { get; set; }
        public int tamanho { get; set; }
        public int id_bl { get;set; }
    }
}